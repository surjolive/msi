# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.0] - 2026-08-15

### Added
- Initial repository setup
- com.dts.freefireth.cfg configuration file
- MSI-APP-Player.zip application
- README documentation
- License file
- .gitignore configuration
